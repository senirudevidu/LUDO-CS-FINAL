#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "types.h"
#include "logic.h"
#include "logic.c"

int main()
{       
    srand(time(0));
    runThis();
}
